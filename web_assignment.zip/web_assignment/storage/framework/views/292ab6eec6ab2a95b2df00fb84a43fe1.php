<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2>Edit Project Details</h2>

        <form method="POST" action="<?php echo e(route('updateProject', ['id' => $project->id])); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="mb-3">
                <label for="project_name" class="form-label">Project Name:</label>
                <input type="text" id="project_name" name="project_name" class="form-control" value="<?php echo e($project->name); ?>">
            </div>

            <div class="mb-3">
                <label for="project_description" class="form-label">Project Description:</label>
                <textarea id="project_description" name="project_description" class="form-control"><?php echo e($project->description); ?></textarea>
            </div>

            <div class="mb-3">
                <label for="project_category" class="form-label">Project Category:</label>
                <input type="text" id="project_category" name="project_category" class="form-control" value="<?php echo e($project->category); ?>">
            </div>

            <button type="submit" class="btn btn-primary">Update Project</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Muhammad AB\NUST\5th Semester\Web Engineering\Assignments\Assignment 03\seecs-open-house\web_assignment\resources\views/layouts/editProjectForm.blade.php ENDPATH**/ ?>