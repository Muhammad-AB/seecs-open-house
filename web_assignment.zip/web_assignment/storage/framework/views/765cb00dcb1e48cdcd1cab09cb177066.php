<?php $__env->startSection('content'); ?>
    <div class="container">

        <h1>Welcome, Admin</h1>

        <h2>All Projects</h2>

        <?php $__empty_1 = true; $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="card mb-3">
                <div class="card-body">
                    <h5 class="card-title">ProjectName: <?php echo e($project->name); ?></h5>
                    <p class="card-text">Location: <?php echo e($project->location->name); ?></p>
                    <p class="card-text">Status: <?php echo e($project->status); ?></p>
                    <a href="<?php echo e(route('admin.projectDetails', ['id' => $project->id])); ?>" class="btn btn-primary">View Details</a>
                </div>
            </div>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p>No projects available.</p>
       <?php endif; ?>

        <div class="mt-4">
            <h2>Map</h2>
            <img src="<?php echo e(asset('images/map.png')); ?>" alt="Map Image" class="img-fluid">
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Muhammad AB\NUST\5th Semester\Web Engineering\Assignments\Assignment 03\seecs-open-house\web_assignment\resources\views/admin_dashboard.blade.php ENDPATH**/ ?>