<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2>Edit Project Details</h2>

        <form method="POST" action="">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="mb-3">
                <label for="project_name" class="form-label">Project Name:</label>
                <input type="text" id="project_name" name="project_name" class="form-control" value="">
            </div>

            <div class="mb-3">
                <label for="project_description" class="form-label">Project Description:</label>
                <textarea id="project_description" name="project_description" class="form-control"></textarea>
            </div>

            <div class="mb-3">
                <label for="project_category" class="form-label">Project Category:</label>
                <input type="text" id="project_category" name="project_category" class="form-control" value="">
            </div>

            <button type="submit" class="btn btn-primary">Update Project</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Muhammad AB\NUST\5th Semester\Web Engineering\Assignments\Assignment 03\seecs-open-house\web_assignment\resources\views/layouts/student_edit_project_detail.blade.php ENDPATH**/ ?>