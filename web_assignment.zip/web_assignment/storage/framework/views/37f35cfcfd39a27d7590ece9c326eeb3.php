<?php $__env->startSection('content'); ?>
<div class="container">

    <h2>Project Details</h2>

    <div class="card mb-3">
        <div class="card-body">
            <h5 class="card-title">Project Name: <?php echo e($project->name); ?></h5>
            <p class="card-text">Location: <?php echo e($project->location->name); ?></p>
            <p class="card-text">Status: <?php echo e($project->status); ?></p>
        </div>
    </div>

    <h3>Evaluators</h3>

    
    <p>No evaluators assigned.</p>
    <a href="" class="btn btn-primary">Assign Evaluator</a>
    
    <ul>
        <?php $__currentLoopData = $project->evaluations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evaluation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $__currentLoopData = $evaluation->evaluator; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evaluator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    

    <h3>Location</h3>

    <form method="POST" action="">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="mb-3 bg-light">
            <label for="projectLocation">Select Project Location:</label>
            <select id="projectLocation" name="projectLocation" class="form-select" required>
                
                <option value=""></option>
                <option value="A0">A0</option>
                <option value="A1">A1</option>
                <option value="A1">A2</option>
                <option value="A1">A3</option>
                <option value="A1">B1</option>
                <option value="A1">B2</option>
                <option value="A1">B5</option>
                
            </select>
        </div>

        <button type="submit" class="btn btn-primary">Update Location</button>
    </form>

    <div class="mt-4">
        <img src="<?php echo e(asset('images/map.png')); ?>" alt="Map Image" class="img-fluid">
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Muhammad AB\NUST\5th Semester\Web Engineering\Assignments\Assignment 03\seecs-open-house\web_assignment\resources\views/admin_project_details.blade.php ENDPATH**/ ?>