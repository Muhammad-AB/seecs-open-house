<?php $__env->startSection('content'); ?>
    <div class="container">

        <h2>Project Details</h2>

        <div class="card mb-3">
            <div class="card-body">
                <h5 class="card-title">Project Name: "$project->name "</h5>
                <p class="card-text">Description: $project->description "</p>
                <p class="card-text">Group Members: " implode(', ', $project->groupMembers->pluck('name')->toArray()) "</p>
                <p class="card-text">Category: " $project->category "</p>
                <p class="card-text">Location: " $project->location "</p>
                <p class="card-text">Status: " $project->status "</p>
            </div>
        </div>

        
                <h3>Mark Project</h3>

                <form method="POST" action="">
                    <?php echo csrf_field(); ?>

                    <div class="mb-3 bg-light">
                        <label for="projectMarks">Mark the Project (1 - 10):</label>
                        <input type="number" id="projectMarks" name="projectMarks" class="form-control" min="1" max="10" step="0.5" required>
                    </div>

                    <button type="submit" class="btn btn-primary">Submit Mark</button>
                </form>
        

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Muhammad AB\NUST\5th Semester\Web Engineering\Assignments\Assignment 03\seecs-open-house\web_assignment\resources\views/layouts/eval_view_project.blade.php ENDPATH**/ ?>