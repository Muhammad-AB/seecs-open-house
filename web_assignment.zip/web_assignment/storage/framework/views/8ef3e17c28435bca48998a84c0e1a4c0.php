<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Welcome, </h1>

        <h2>Project Details</h2>

        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Project Name: </h5>
                <p class="card-text">Description: </p>
                <p class="card-text">Group Members: </p>
                <p class="card-text">Category: </p>
                <p class="card-text">Location: </p>
                <p class="card-text">Status: </p>--
                <a href="" class="btn btn-primary">Edit Project</a>
            </div>
        </div>

        <h2>Evaluation Status</h2>

        <div class="card">
            <div class="card-body">
                <p>Total Evaluators: 3</p>
                <p>Evaluators Marked: </p>
                <p>Total Marks: </p>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Muhammad AB\NUST\5th Semester\Web Engineering\Assignments\Assignment 03\seecs-open-house\web_assignment\resources\views/student_dashboard.blade.php ENDPATH**/ ?>