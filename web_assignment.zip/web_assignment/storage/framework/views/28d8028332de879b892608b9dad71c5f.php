<?php $__env->startSection('content'); ?>
    <div class="container">

        <h1>Welcome, Admin</h1>

        <h2>All Projects</h2>

        
            <div class="card mb-3">
                <div class="card-body">
                    <h5 class="card-title">ProjectName: </h5>
                    <p class="card-text">Location: </p>
                    <p class="card-text">Status: </p>
                    <a href="" class="btn btn-primary">View Details</a>
                </div>
            </div>
       
            <p>No projects available.</p>
       

        <div class="mt-4">
            <h2>Map</h2>
            <img src="<?php echo e(asset('images/map.png')); ?>" alt="Map Image" class="img-fluid">
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Muhammad AB\NUST\5th Semester\Web Engineering\Assignments\Assignment 03\seecs-open-house\web_assignment\resources\views/layouts/admin_dashboard.blade.php ENDPATH**/ ?>