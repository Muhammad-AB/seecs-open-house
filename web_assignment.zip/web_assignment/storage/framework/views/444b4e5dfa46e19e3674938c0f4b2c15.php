<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Welcome, <?php echo e(auth()->user()->name); ?></h1>

        <h2>Project Details</h2>

        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Project Name: <?php echo e($project->name); ?></h5>
                <p class="card-text">Description: <?php echo e($project->description); ?></p>
                <p class="card-text">Group Members: <?php echo e(implode(', ', $project->groupMembers->pluck('name')->toArray())); ?></p>
                <p class="card-text">Category: <?php echo e($project->category); ?></p>
                <p class="card-text">Location: <?php echo e($project->location); ?></p>
                <p class="card-text">Status: <?php echo e($project->status); ?></p>
                <a href="<?php echo e(route('editProjectForm', ['id' => $project->id])); ?>" class="btn btn-primary">Edit Project</a>
            </div>
        </div>

        <h2>Evaluation Status</h2>

        <div class="card">
            <div class="card-body">
                <p>Total Evaluators: 3</p>
                <p>Evaluators Marked: <?php echo e($evaluatorsMarkedCount); ?></p>
                <p>Total Marks: <?php echo e($totalMarks); ?></p>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Muhammad AB\NUST\5th Semester\Web Engineering\Assignments\Assignment 03\seecs-open-house\web_assignment\resources\views/layouts/groupDashboard.blade.php ENDPATH**/ ?>