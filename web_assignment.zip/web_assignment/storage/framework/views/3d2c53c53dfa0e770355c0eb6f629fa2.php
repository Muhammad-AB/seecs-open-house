<?php $__env->startSection('content'); ?>
<div class="container">

    <h2>Project Details</h2>

    <div class="card mb-3">
        <div class="card-body">
            <h5 class="card-title">Project Name: <?php echo e($project->name); ?></h5>
            <p class="card-text">Description:<?php echo e($project->description); ?></p>
            <p class="card-text">Group Members: <?php echo e($project->students[0]->user->name); ?> </p>
            <p class="card-text">Category: <?php echo e($project->category->name); ?></p>
            <p class="card-text">Location: <?php echo e($project->location->name); ?></p>
            <p class="card-text">Status: <?php echo e($project->status); ?></p>
        </div>
    </div>

    <?php if(auth()->check()): ?>
        <?php if(auth()->user()): ?>
            <h3>Mark Project</h3>

            <form method="POST" action="<?php echo e(route('mark.project', ['id' => $project->id])); ?>">
                <?php echo csrf_field(); ?>

                <div class="mb-3 bg-light">
                    <label for="projectMarks">Mark the Project (1 - 10):</label>
                    <input type="number" id="projectMarks" name="projectMarks" class="form-control" min="1" max="10" step="0.5" value='<?php echo e($project->marks); ?>' required>
                </div>

                <button type="submit" class="btn btn-primary">Submit Mark</button>
            </form>
        <?php endif; ?>
    <?php endif; ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Muhammad AB\NUST\5th Semester\Web Engineering\Assignments\Assignment 03\seecs-open-house\web_assignment\resources\views/eval_project.blade.php ENDPATH**/ ?>